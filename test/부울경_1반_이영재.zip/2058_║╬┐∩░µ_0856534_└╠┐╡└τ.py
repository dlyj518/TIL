a,b=input(),0
for i in range(len(a)):
    b+=int(a[i])
print(b)